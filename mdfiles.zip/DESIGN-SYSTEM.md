# &Insights — MEE Client Analytics Phase 2 · Design System

This is the canonical style reference for every dashboard mockup in `MEE_Client_Analytics_P2`.
When building or revising any page, follow this file exactly. Where a request conflicts with
this file, ask before diverging. The goal is that every page looks like it came from the same
product — nothing should read as HCSC-branded or as a generic template.

These are static HTML/CSS/JS mockups that must stay **Power BI–feasible**: everything here maps
to Card visuals, a Matrix with conditional formatting, native charts, and slicers. No custom visuals.

---

## 1. Color palette

Use these values and no others. Do not introduce magenta, forest green, pink/blue pastel bands,
or multi-hue rainbow ramps — those are off-palette tells from older wireframes.

**Core**
- Teal (primary): `#0e7490`
- Teal mid: `#0891b2`
- Page background: `#f8fafc`
- Surface / cards: `#ffffff`
- Border: `#e2e8f0`
- Border mid: `#cbd5e1`
- Text: `#0f172a`
- Sub-text: `#64748b`
- Muted: `#94a3b8`

**Semantic (conditional formatting)**
- Red — increase / unfavorable: `#dc2626`
- Green — decrease / favorable: `#16a34a`
- Convention: **red = increase, green = decrease.** Apply to YoY, CAGR, Historical, Variance, and Bmk Var.

**Category / series accents**
- Blue: `#1d4ed8`
- Indigo / violet: `#7c3aed`
- Amber / gold: `#d97706`
- Benchmark line: `#64748b` (dashed) or amber `#f59e0b` where a series color is needed

**Claim-type mapping (fixed across all pages)**
- Medical: `#1d4ed8`
- Behavioral Health: `#0891b2`
- Pharmacy: `#7c3aed`

**Cohort mapping (HCC status pages)**
- HCC ($100K+): `#1d4ed8`
- Pre-HCC ($50–100K): `#d97706`
- Non-HCC ($0–50K): `#16a34a`

**Tints (for badges, callouts, projection zones)**
- Teal tint background: `#f0fdfa`
- Teal tint border: `#a5dee9`

---

## 2. Typography

- Body / UI: **Segoe UI**, system-ui fallback.
- Page titles only: **Georgia** serif.
- Eyebrow above title: 11px, uppercase, letter-spacing ~0.13em, `#64748b`, 600 weight.
- Numbers in tables and cards: always `font-variant-numeric: tabular-nums`.
- Type scale (typical): page title ~30px serif; card/section title 15–17px; body 12.5–13px;
  table header 11.5px uppercase letter-spaced; captions 11px `#94a3b8`.

---

## 3. Page skeleton (every page has these, in this order)

1. **Sidebar** (fixed left) — see §4.
2. **Sticky header** — eyebrow `MEE CLIENT ANALYTICS · PHASE 2`, Georgia serif page title,
   right side: Filters button + `1Y / 2Y / 3Y / 4Y / 5Y` buttons (5Y active = teal fill, white text).
3. **Sub-header row** — left: `Current Incurred: 01/01/2025 – 12/31/2025 | Current Paid: 01/01/2025 – 02/28/2026`.
   Right: `YEAR LOOKBACK` slider with stops `Y5 Y4 Y3 Y2 Y1`.
4. **(optional) Claim-type toggles** — see §6.
5. **Content** — cards, charts, tables.
6. **Footer** — `← Return to Navigation` link.
7. **Filters overlay** — slide-over panel triggered by the Filters button.

---

## 4. Sidebar (domain-aware)

- Dark navy `#1e293b`, 200px fixed width, full height.
- Top: `&Insights` logo (the `&` in teal `#0891b2`) with `MEE Client Analytics` subtitle beneath.
- `← All Domains` link → `index.html`.
- Section label (uppercase, letter-spaced, dim) naming the current domain, e.g. `DEMOGRAPHICS`.
- Nav items = only the pages in THIS domain. Each may carry a small `P2` pill.
- `GENERAL` section near the bottom: `Settings` · `Return to Navigation Hub`.
- Optional user block at the very bottom (avatar, name, role).
- **Active item:** teal `#0891b2` left border + slightly lighter background. Inactive: dimmed.
- Do **not** use a flat global list of every dashboard. The sidebar is scoped to the current domain only.

---

## 5. Cards, tables, charts

**Cards**
- White, border-radius 12px, `box-shadow: 0 1px 8px rgba(0,0,0,0.07)`, 1px `#e2e8f0` border.
- KPI cards: white bg, 1px `#e2e8f0` border, 10px radius, no colored tint fills.
  Label 10.5px uppercase letter-spaced `#64748b`; value ~26px 600; caption 11px `#94a3b8`.
  Color lives on the **value** only, and only by meaning (red increase / green favorable / teal neutral).

**Tables (Matrix)**
- Header row: teal `#0e7490`, white text, single-line labels (never wrap the header).
- `table-layout: fixed`, column widths as explicit percentages summing to 100. **No horizontal scroll.**
- Uniform row height; body ~9px vertical padding; body 12.5px / header 11.5px.
- `tabular-nums` throughout; currency 2 decimals; counts with thousands separators.
- Row-group labels **horizontal** (never rotated), vertically centered against their rows,
  with a **4px left accent rule** in the group's color.
- Account = dark; Benchmark = muted grey; Variance = italic in parentheses.
- Total / summary rows: 2px `#0f172a` top border, `#f8fafc` background, 600 weight, slightly larger.
- Conditional formatting per §1 (red increase / green decrease).

**Charts (HTML canvas)**
- Set `canvas.width/.height` to CSS size × `devicePixelRatio`, then `ctx.scale()` — crisp, not blurry.
  Recompute plot area from actual `clientWidth`; redraw on `resize`. No hardcoded pixel widths.
- Gridlines: 1px `#f1f5f9`, horizontal only. No vertical gridlines, no chart border, no axis spines.
- Lines: smooth (quadratic / catmull-rom), ~2.5px; markers with a 2px white halo so crossings stay legible.
- Area fills: subtle vertical gradient from ~`rgba(…,0.08)` to transparent, on the primary line only.
- Legends: small colored dot + label, on the title row (right-aligned) or directly beneath it.
- Hover: floating tooltip div, `display:none` until hover, follows cursor, flips near right edge so
  it never clips. White bg, 1px `#e2e8f0`, 10px radius, `box-shadow 0 4px 16px rgba(15,23,42,.10)`.
- **Projection/forecast convention:** the forecast segment renders **dashed at ~70% opacity**,
  projection markers are **hollow** (white fill, colored stroke), and the projected column/zone is
  shaded `#f8fafc` with a small italic `PROJECTED` label. In tables, the projection column gets a
  `#f0fdfa` tint and a 2px `#0e7490` left border running the full column height.

**Badges (e.g. LIVE)**
- 10px uppercase letter-spaced, teal `#0e7490` text on `#f0fdfa`, 1px `#a5dee9` border,
  border-radius 999px, ~3px 8px padding.

---

## 6. Claim-type toggles (the canonical pill treatment)

Used wherever the user filters by Medical / Behavioral Health / Pharmacy.

- Labels in full: **Medical · Behavioral Health · Pharmacy** (not BH / Rx).
- Three pills, **equal width** (`flex:1`, `max-width:190px`), `gap:10px`.
- Pill shape: `border-radius:999px`, `padding:10px 18px`, 13px / 600, inline-flex, centered,
  `gap:9px`, `transition: all .16s ease`.
- **Selected:** white bg, 1.5px border in the claim color, text `#0f172a`,
  `box-shadow:0 1px 3px rgba(15,23,42,.10)`, 8px filled dot in the claim color.
- **Deselected:** bg `#f1f5f9`, 1.5px transparent border, text `#94a3b8`, dot `#cbd5e1`, no shadow;
  hover bg `#e8edf3`.
- **Behavior:** multi-select. All selected by default. At least one must stay selected (clicking the
  last active pill does nothing). Toggling live-updates every visual and table on the page.
- Do **not** add a `CLAIM TYPES` label unless a page specifically needs it — the pills are self-explanatory.
- **Power BI mapping:** horizontal multi-select slicer, Tile style.

> Alternate (segmented-control) styling exists on some pages; the pill treatment above is the current
> default. Match whichever the target page's siblings already use — consistency within a domain wins.

---

## 6b. Navigation Hub (index.html)

The hub is a **landing page**, not the sidebar shell — it has no left sidebar. Structure, top to bottom:

1. **Top meta strip** — three (sometimes more) labelled blocks side by side:
   - `PURPOSE` — one-line description of the summary's role.
   - `GOAL` — one-line objective.
   - `VISIBLE TO MARKET SEGMENTS` — a row of market-segment pills (see below).
   Labels are uppercase letter-spaced `#64748b`; body text `#0f172a`.

2. **START HERE hero band** — teal-tinted (`#f0fdfa`) full-width card with a subtle teal left accent.
   Eyebrow `START HERE`, serif `Executive Summary` title, a one-line description, and a right-aligned
   `OPEN EXECUTIVE SUMMARY ›` button (solid teal `#0e7490`, white text).

3. **ANALYTIC DOMAINS** — section label, then a **3-column grid of domain cards** (2 rows for 6 domains).
   Each card:
   - Dark top-border accent, white body, 12px radius, standard card shadow.
   - `AVAILABLE` badge top-right (green text on pale green pill). Use a muted/"soon" variant for
     not-yet-built domains.
   - Serif domain title (teal), a 2–3 line description.
   - Footer count line: `<n> Dashboards` and, where applicable, `<n> Report` with small icons.
   - `VIEW ›` link bottom-right.
   - Cards are equal height within a row; the whole card is the click target to the domain landing page.

Current domain set and counts (keep in sync with the build):
Trend / Components of Trend (4 dashboards, 1 report) · Demographics (11, 1) · Service Category (3, 1) ·
High-Cost Claimants (3) · Emergency Room (2) · Disease Category (2).

### Market-segment pills (hub meta strip)
- Fixed set: `Down Market` · `ENA` · `Jumbo` · `HET Full` · `HET Lite`, plus a `Phase 2` tag.
- The five segments render as neutral outline pills; the `Phase 2` tag uses a warm accent
  (distinct from the segment pills) to read as a status marker, not a segment.
- These are display tags on the hub, not interactive filters.

---

## 7. Layout rules (global)

- **No fixed card heights.** Cards grow to fit content. Chart canvases cap ~180–220px.
- `overflow: visible`, natural stacking — nothing gets clipped.
- **No horizontal scroll on any table** — use `table-layout: fixed` with % widths summing to 100.
- Multi-column page grids: use `grid-template-columns: minmax(0, X%) minmax(0, Y%)` — the `minmax(0,…)`
  is required so a wide table can't force its column past its share and crush the neighbor.
- Use `align-items: start` on page grids so a shorter column ends at its natural height instead of
  stretching to match a taller neighbor. Never pad a column with dead space to force equal heights.
- Panels shrink to their content — no fixed/min height that leaves an empty region below the content.
- Mini-tables and labels must render in full — never truncate a header or clip the bottom rows.
- Responsive: below ~1200–1280px, collapse multi-column layouts to a single stacked column.
- Respect `prefers-reduced-motion` — skip load animations to their final frame.

---

## 8. Consolidated / toggle-driven pages

Several domains collapse multiple old pages into one driven by the claim-type toggles:
- Retire the old per-page nav items; the sidebar shows the single consolidated item.
- Removing a series via toggle removes it from **both** chart and table (not greyed — removed from flow).
- A **Total** row/line is a live rollup of only the currently-selected series, not a static category.
- Benchmark logic: when all series are selected, Total compares against the **Total benchmark**
  (a distinct number, not the sum of the individual benchmarks); with a subset selected, Total
  benchmark is the sum of the selected series' benchmarks.

---

## 9. Copy conventions

- Sentence case for labels and buttons. Active voice on controls ("Return to Navigation Hub").
- Name things by what the user controls, not by how the data is built.
- Use a real middle-dot character `·`, never the literal `&middot;` entity.
- Eyebrows/section labels uppercase + letter-spaced; everything else sentence case.

---

## 10. Feasibility guardrails (call these out when relevant)

- Cross-visual column alignment (table years lining up under chart years) is **not** natively
  supported in Power BI — it's best-effort manual sizing and only holds at one lookback setting.
- A slicer cannot render a measure inside its tiles — value-in-the-control designs become a slicer
  plus aligned Card visuals.
- Dashed projection segments come from a separate forecast series/measure, not one continuous line.
- Account/Benchmark/Variance as rows (not columns) needs an unpivoted metric dimension + a SWITCH measure.
