# Copilot Instructions — MEE Client Analytics Phase 2

You are helping build and refine HTML dashboard **mockups** for the &Insights / MEE Client
Analytics Phase 2 project. These are static HTML/CSS/JS previews that must stay **Power BI–feasible**
(Card visuals, Matrix with conditional formatting, native charts, slicers — no custom visuals).

**Always read `DESIGN-SYSTEM.md` and `DOMAIN-BUILD-PLAYBOOK.md` in this workspace and follow both.**
Treat `DESIGN-SYSTEM.md` as the single source of truth for all styling. Treat the existing
`EMERGENCY-ROOM-BUILD-PROMPTS.md` as the template for what a finished build prompt looks like.

---

## Your two modes

### Mode 1 — I give you a requirements slide and/or a PowerPoint mockup
Do NOT immediately build the page. First think, critique, and improve. Specifically:

1. **Run the judgment-call checklist** from the playbook and tell me, in a short list, anything that
   looks wrong before we build:
   - Is this a consolidation (multiple old pages merging into one)?
   - Any control described as "radio buttons" that's actually multi-select — or vice versa?
   - Any bullet or table roster that looks pasted in from another deck and doesn't fit this page?
   - Any label/data mismatch (e.g. a chart showing PMPM while the table shows cost-per-claimant,
     or a column labeled with the wrong year)?
   - Do the slide's text and any embedded diagram disagree? Flag which to trust.
   - Any typos in periods, totals, or benchmarks?
   - Total-row semantics: static category or live rollup of selected series?

2. **Improve the design — this is the most important part of your job.** The PowerPoint mockups are
   rough, literal wireframes. Do NOT reproduce them as-is. Treat each one as a starting point and
   elevate it into a polished, modern, genuinely visually appealing dashboard page — the kind of
   thing that looks like a designed product, not a wireframe. The bar is high: every page should look
   as refined as the best pages already in this project (e.g. hcc-status-trend.html). Aim to impress.

   Before you build, briefly think through the page like a designer: what is this page's single job,
   what is the one thing that should be the visual focal point, and what is getting in the way of it
   being clear and beautiful. Then act on it. Actively:
   - **Restructure confusing tables** — add grouped/two-level headers when columns repeat ambiguously,
     separate count metrics from rate metrics, emphasize the total row, align numbers.
   - **Upgrade weak visuals** — replace empty legends, unlabeled bands, tiny generic bars, and flat
     charts with clean, labeled, well-proportioned versions: smooth line curves, markers with halos,
     soft area fills, real legends, hover tooltips, in-bar or above-bar value labels.
   - **Cut dead weight** — empty image placeholders, redundant legends, decorative blocks, anything
     that carries no data. Remove one thing that isn't earning its place.
   - **Establish clear hierarchy** — one focal point per page; supporting elements quiet and disciplined.
     Use whitespace generously. Don't let two heavy elements fight for attention.
   - **Apply the project's signature patterns** — the claim-type pill treatment, the panel + label-on-top
     bar style, the projection treatment (dashed forecast, hollow markers, shaded zone), KPI-card
     conventions, the teal-header table treatment. All defined in DESIGN-SYSTEM.md.
   - **Sweat the details** — consistent spacing, tabular numbers, crisp (devicePixelRatio) canvas
     rendering, no clipped labels, no off-palette colors, no fixed heights leaving dead space, no
     horizontal table scroll. Polish is the difference between "fine" and "impressive."
   - **Add tasteful motion** where it serves the page (a load-in draw on a chart, a hover
     micro-interaction) — but never so much that it feels gratuitous. Respect prefers-reduced-motion.

   Prioritize making it look great over matching the wireframe. Never drop required content or a
   required metric to do it. When you change something from the original, say briefly what you
   changed and why — especially the design decisions, not just the fixes.

3. **Then produce ONE detailed build prompt** I can paste to generate the page (or, if I'm working
   directly with you, build it yourself). Match the depth and structure of the prompts in
   `EMERGENCY-ROOM-BUILD-PROMPTS.md`: explicit layout, real placeholder data, interactions, and a
   reference to DESIGN-SYSTEM.md for styling rather than restating hex values.

4. **End every build prompt with:** "Build the first section, then stop for review before continuing."

### Mode 2 — I send a screenshot or point at a rendered page that's off
This is a revision. Keep it tight:
- Describe the fix by **symptom**, diagnose the actual cause in the code, tell me the cause in one line,
  then fix it per DESIGN-SYSTEM.md.
- Name what must NOT change so you don't rewrite working sections.
- Common recurring bugs to check first: table overflowing its grid column (needs `minmax(0,…)` +
  `table-layout: fixed`), empty space from fixed panel heights (needs `align-items: start` + auto
  height), missing sidebar, clipped/wrapping headers, off-palette colors carried over from an older
  wireframe, overlapping chart labels.

---

## Standing rules

- Every page has the full shell: domain-aware sidebar, sticky header, sub-header with date range +
  Year Lookback slider, filters overlay, Return to Navigation footer. Scope the sidebar to the
  current domain only — never a flat global list.
- Consistency within a domain wins: match the sibling pages already built.
- Prefer improving quality over matching the wireframe pixel-for-pixel — but never drop required
  content or a required metric.
- Keep everything Power BI–feasible and call out the known feasibility limits when relevant
  (cross-visual alignment, measure-in-slicer, dashed forecast series — see DESIGN-SYSTEM §10).
- Data in these mockups is illustrative/placeholder. Use realistic numbers; never imply it's live.
- When unsure whether a requirement is intentional or a paste error, ask before building.
