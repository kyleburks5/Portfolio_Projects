# Domain Build Playbook

How we turn a domain's requirements + PowerPoint mockups into finished, on-theme pages.
Pairs with `DESIGN-SYSTEM.md` (the canon Copilot reads). This file is the process **you** read
when starting a domain.

---

## The loop

1. **You send** the requirements slide(s) and the PowerPoint mockup(s) for the domain.
2. **We resolve the judgment calls first** (see checklist below) — before any prompt is written.
   This is the step that catches pasted-in bullets, mislabeled columns, and ambiguous toggles.
3. **We turn each page into a build prompt** that references `DESIGN-SYSTEM.md` instead of
   re-specifying the theme.
4. **You paste the prompt into Copilot**, one page (or one section) at a time.
5. **You send back a screenshot** of the result; we write a tight fix prompt for whatever's off.

---

## Judgment-call checklist (do this before writing prompts)

These are the things that go wrong when you build straight from a slide. Check each:

- **Is this a consolidation?** "Replace A/B/C with…" or a toggle that shows multiple things at once
  usually means several old pages merge into one. Confirm which files retire and which nav items go.
- **Radio vs. multi-select.** Slides say "radio buttons" loosely. If more than one option can be
  active at once, it's a multi-select slicer (pills), not a bookmark/radio group.
- **Was a bullet pasted from another deck?** Watch for cohort rosters (Subscriber/Spouse/Dependant/
  PMPM/Risk/%HCC) or "Exit/Entry/Continuously Enrolled" showing up on a page where they don't fit.
  Flag before building.
- **Column/label mismatches.** e.g. a chart showing PMPM while the table below still shows
  cost-per-claimant, or a header labeled "2021 Comparison" when it's actually the 2025 value.
- **Diagram vs. bullets.** When a slide's text and its embedded table diagram disagree on order,
  the diagram is usually the more specific artifact — but confirm.
- **Typos in periods/labels.** "20206", stray benchmark values — sanity-check numbers before they
  get baked into a prompt.
- **Total semantics.** Is the Total a static category or a live rollup of selected series? Which
  benchmark does it compare against when all series are on? (See DESIGN-SYSTEM §8.)

---

## Prompt structure for a NEW page

Keep this skeleton. It front-loads the reference and the data so Copilot doesn't improvise.

```
Create <filename>.html for the <Domain> domain. Follow DESIGN-SYSTEM.md exactly — sidebar,
header, sub-header, pills, cards, tables, charts, and layout rules all come from there. Open
<a good sibling page> as a reference implementation. Use realistic placeholder numbers.

Page title: <title>

SIDEBAR: <Domain> section; nav items: <list>; <this page> active.

<CONTENT — describe each visual: what it is, its data, its interactions. Reference the design
system for styling instead of restating hex values.>

<DATA — paste the actual series so numbers aren't invented.>

Build the <first section> first and stop so I can review before you continue.
```

- New pages have genuinely long prompts because the spec **is** the information (data, interactions).
- Styling should be one line ("follow DESIGN-SYSTEM.md"), not a re-listing of the theme.
- Always end with "build one section, then stop" so you can course-correct.

## Prompt structure for a REVISION

Revisions should be short — Copilot can see the file.

```
In <filename>.html: <what's wrong, described by symptom>. Diagnose the cause, tell me in one line,
then fix per DESIGN-SYSTEM.md. Don't change <the stuff that's fine>.
```

- Describe the **symptom** ("table overflows and crushes the right column"), let Copilot find the cause.
- Name what must NOT change, so it doesn't rewrite working sections.
- For pure rendering bugs you can point at in the editor, you often don't need me at all —
  ask Copilot directly with the file open.

---

## When to use which tool

- **GitHub Copilot (file open in VS Code):** anything mechanical or diagnostic — overflow, clipped
  columns, missing sidebar, spacing/height gaps, applying the theme to an old page. It can read the
  actual CSS, so keep these prompts short.
- **A chat assistant (screenshots + slides):** the judgment calls — consolidation scope, toggle
  semantics, pasted-in bullets, data mismatches, "does this even make sense," and net-new visual
  designs (e.g. the projection chart) where the treatment has to be invented, not diagnosed.

Rule of thumb: if you're photographing a screen to describe a file Copilot could just read, that
part belongs in Copilot. Bring the thinking here.

---

## Standard domain page set (reference)

Most domains land on a mix of: an **Overview/scorecard** (KPI cards + trend charts), one or more
**detail tables** (five-year, Account/Benchmark/Variance, YoY/CAGR/Historical), and where relevant a
**bookmark/tab page** collapsing several sub-views (e.g. per-disease, per-care-setting) behind a tab
switcher. Consolidated toggle-driven pages (claim-type pills driving chart + table + Total) recur
across Trend, Demographics (Entry/Exit), High-Cost Claimants, and Disease.

---

## Housekeeping after a consolidation

- Update the sidebar nav on the OTHER pages in the domain to drop retired items.
- Update the Navigation Hub (`index.html`) domain card.
- Keep retired HTML files until the consolidation is signed off — don't delete early.
