# Emergency Room Domain — Build Prompts

Two pages for the Emergency Room domain (already listed AVAILABLE · 2 Dashboards on the hub).
Paste each prompt into Copilot **one at a time**, and within each, let Copilot build the first
section and stop before continuing. Both prompts assume `DESIGN-SYSTEM.md` is in the repo root.

Domain decisions locked:
- Two pages: Frequent Flier Summary · Emergent vs Non-Emergent.
- The Emergent/Non-Emergent control is a **single-select bookmark toggle** (one view at a time),
  styled as tabs — NOT the multi-select claim-type pills.
- Metric roster (from the requirements slide): Characteristics (Emergent/Non-Emergent, ER Visit
  Count, ER Visit Band) · Membership (Member Months) · Financial (Allowed, Paid) · Utilization
  (Claimants, Admissions, Days, OP Visits, Professional Visits, Professional Services, Claims) ·
  Risk N/A.
- KPI scorecard from the requirements slide is treated as future work, not built here (hub says 2 dashboards).

═══════════════════════════════════════════════════════════════════════
## PAGE 1 — emergency-room-frequent-flier.html
═══════════════════════════════════════════════════════════════════════

```
Create emergency-room-frequent-flier.html for the Emergency Room domain. Follow DESIGN-SYSTEM.md
exactly — sidebar, header, sub-header, cards, tables, charts, and layout rules all come from there.
Open hcc-status-trend.html, claims-pmpm-trends.html, and trend-financials.html as reference
implementations. This replaces an older HCSC-branded wireframe — use none of that styling. Use
realistic placeholder numbers.

Page title: 'Emergency Room – Frequent Flier Summary'

SIDEBAR: EMERGENCY ROOM domain section; nav items — Frequent Flier Summary (ACTIVE) · Emergent vs
Non-Emergent. GENERAL section: Settings · Return to Navigation Hub.

LAYOUT: two-column content grid, grid-template-columns: minmax(0, 56%) minmax(0, 44%), 20px gap,
align-items: start.

LEFT COLUMN — the Frequent Flier table, in one card:
- Title 'ER Utilization by Visit Frequency', subtitle 'Claimants, encounters, and spend by annual
  ER visit count'
- The source wireframe repeats 'ER Visits / % of Total' three times, which is unreadable. Give the
  table a TWO-LEVEL header that groups the columns clearly:
  - Row 1 (group band, teal #0e7490): 'VISIT BAND' | 'CLAIMANTS' (spans 2) | 'ENCOUNTERS' (spans 2)
    | 'SPEND' (spans 2)
  - Row 2 (column header): (blank) | Claimants · % of Total | ER Visits · % of Total | ER Spend · % of Total
- Left column is the visit band: rows 1, 2, 3, 4, 5, 6, 7, 8, 9, 10+
- Body: Claimants as counts, ER Visits as counts, ER Spend as currency, each with its % of Total beside it
- Final TOTAL row emphasized per DESIGN-SYSTEM (2px #0f172a top border, #f8fafc bg, 600 weight);
  the three % columns each sum to 100%
- table-layout: fixed, no horizontal scroll, uniform row height, tabular-nums

RIGHT COLUMN — two stacked cards, each in the clean white-panel style from trend-financials.html
(match its panel padding, border, and label placement):

Card 1 — 'Frequent Flier Rates Over Time':
- Line chart, three lines for visit bands: 1–2 visits (teal #0e7490), 3–4 visits (blue #1d4ed8),
  5+ visits (amber #d97706)
- X axis Y5 · Y4 · Y3 · Y2 · Y1; Y axis % of members
- Real legend (colored dot + label) on the title row, replacing the '[ ] 1-2 visits' placeholders
- Smooth curves, markers with white halos, light horizontal gridlines only, hover tooltip per DESIGN-SYSTEM

Card 2 — 'Top Dx Categories by Frequent Flier':
- Three grouped sets of horizontal bars, one per visit band (1–2, 3–4, 5+), each set labeled on the left
- LABEL TREATMENT — match the trend-financials funnel bars: the diagnosis category NAME sits ABOVE
  its bar (left-aligned, dark text), the VALUE sits to the RIGHT at the bar end, and any % of total
  rides ON the bar in white (right-aligned inside the fill). Bar beneath the name, in the visit band's color.
- Consistent bar heights across all three sets, generous row spacing, category names never clip

Header, sub-header (date range + Year Lookback slider), Filters overlay, and footer per DESIGN-SYSTEM.

Build the sidebar + header + the left table first, then stop for review before the charts.
```

═══════════════════════════════════════════════════════════════════════
## PAGE 2 — emergency-room-emergent.html
═══════════════════════════════════════════════════════════════════════

```
Create emergency-room-emergent.html for the Emergency Room domain. Follow DESIGN-SYSTEM.md exactly.
Open hcc-status-trend.html (for the showcase line chart), disease-detail.html (for the tab toggle
pattern), and trend-financials.html as references. This replaces an older HCSC-branded wireframe —
use none of that styling. Use realistic placeholder numbers.

Page title: 'Emergency Room – Emergent vs Non-Emergent'

SIDEBAR: EMERGENCY ROOM domain section; nav items — Frequent Flier Summary · Emergent vs
Non-Emergent (ACTIVE). GENERAL section: Settings · Return to Navigation Hub.

VIEW TOGGLE — single-select bookmark toggle directly below the sub-header:
- Two options: 'Emergent ER' and 'Non-Emergent ER'
- Single-select (one active at a time, NOT multi-select). Emergent active by default.
- Style as the tab/underline switcher used on disease-detail.html — active tab teal #0e7490 with a
  2px underline, inactive #64748b. Do NOT use the claim-type pill styling here.
- Switching swaps ALL data on the page — the line chart and the table both reflect the selected view.

MAIN CHART — this is the showcase visual; match the quality of the hcc-status-trend line chart:
- Card title 'Monthly PMPM · Account vs Benchmark', subtitle updates with the toggle ('Emergent ER'
  / 'Non-Emergent ER')
- Two lines across the monthly reporting window (Apr Y-something through Mar, ~36 months): Account
  (teal #0e7490, solid) and Benchmark (#64748b, dashed)
- Soft area fill under the Account line (vertical gradient from rgba(14,116,144,0.10) to transparent)
- Smooth curves, markers with white halos, light horizontal gridlines only, Y axis 'Monthly PMPM'
  currency, X axis month labels
- Label the latest Account and Benchmark endpoints with their values (e.g. $44.65 / $57.25 style),
  nudged apart so they never overlap
- Hover tooltip per DESIGN-SYSTEM; drop the raw 'Zoom' control from the wireframe
- Crisp canvas rendering (devicePixelRatio + ctx.scale), redraw on resize, full card width

DETAIL TABLE — below the chart, full width, one card:
- Columns: Metric | 2024 | 2025 | 2026 | YoY (+/-%) | Historical (+/-%)
- Row groups in order: PMPM · $ / Visit · Visits / 1K · Claimants / 1K
- Each group has three rows: Account · Benchmark · Variance
- Metric-group label horizontal in a left column, vertically centered, with a 4px teal left accent rule
- Account dark, Benchmark muted grey, Variance italic in parentheses
- YoY and Historical get red/green conditional formatting (red = increase, green = decrease);
  Variance rows show '—' in those columns
- table-layout: fixed, no horizontal scroll, uniform row height, tabular-nums
- All values swap when the Emergent/Non-Emergent toggle changes

Example data for the Emergent view (invent a plausible, slightly lower Non-Emergent set for the toggle):
- PMPM: Account 30.09 / 36.47 / 39.44, Benchmark 36.43 / 42.45 / 48.91, Variance -17.4% / -14.1% / -19.4%,
  YoY +8.1%, Historical +37.1%
- $ / Visit: Account 2,251.69 / 2,499.84 / 2,599.77, Benchmark 2,154.64 / 2,429.97 / 2,720.72,
  Variance +4.5% / +2.9% / -4.4%, YoY +4.0%, Historical +15.5%
- Visits / 1K: Account 160.4 / 175.1 / 182.0, Benchmark 202.9 / 209.6 / 215.7, Variance -21.0% /
  -16.5% / -15.6%, YoY +4.0%, Historical +13.5%
- Claimants / 1K: Account 131.9 / 135.9 / 139.2, Benchmark 154.2 / 157.1 / 157.2, Variance -14.5% /
  -13.5% / -11.5%, YoY +2.5%, Historical +5.6%

Header, sub-header (date range + Year Lookback slider), Filters overlay, and footer per DESIGN-SYSTEM.

Build the sidebar + header + the toggle + the line chart first, then stop for review before the table.
```

═══════════════════════════════════════════════════════════════════════
## After both pages are built
═══════════════════════════════════════════════════════════════════════

- The Emergency Room hub card already shows AVAILABLE · 2 Dashboards — no count change needed.
- Confirm both pages' sidebars list exactly these two nav items and cross-link correctly.
- Spot-check: no horizontal scroll on either table, labels never clipped, toggle swaps all data.
